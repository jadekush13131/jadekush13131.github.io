#!/usr/bin/env python3
# coding: utf-8

import argparse
import json
import mimetypes
import os
import subprocess
import sys
import time
from datetime import datetime
from glob import glob
from pathlib import Path
from platform import platform
from typing import Optional

import requests
from rich import print as rprint
from rich.highlighter import JSONHighlighter
from rich.panel import Panel
from rich.progress import Progress, BarColumn, TransferSpeedColumn, TimeRemainingColumn

# Import MultipartEncoder and MultipartEncoderMonitor for streaming upload with progress
from requests_toolbelt.multipart.encoder import MultipartEncoder, MultipartEncoderMonitor


def upload(file: str, best_server: str, folder_id: Optional[str] = None, progress_bar=None, task_id=None):
    f_obj = Path(file)
    content_type = mimetypes.guess_type(f_obj)[0] or 'application/octet-stream'
    upload_url = f'https://{best_server}.gofile.io/uploadFile'

    with open(f_obj, 'rb') as f:
        # Create an encoder to stream the file
        encoder = MultipartEncoder(
            fields={
                'token': os.getenv('GOFILE_TOKEN'),
                'folderId': folder_id,
                'file': (f_obj.name, f, content_type)
            }
        )

        def progress_callback(monitor):
            if progress_bar is not None and task_id is not None:
                # Update progress task to current bytes read
                progress_bar.update(task_id, completed=monitor.bytes_read)

        monitor = MultipartEncoderMonitor(encoder, progress_callback)
        headers = {'Content-Type': monitor.content_type}

        attempt = 0
        while True:
            try:
                resp = requests.post(upload_url, data=monitor, headers=headers)
                break
            except requests.exceptions.ConnectionError:
                rprint(
                    'The connection was refused from the API side! '
                    f'Trying again... ([cyan]{attempt}[/cyan]/10)',
                    style='red')
                time.sleep(2)
                attempt += 1
                if attempt > 10:
                    break
    return resp


def gofile_upload(path: list,
                  to_single_folder: bool = False,
                  verbose: bool = False,
                  export: bool = False,
                  open_urls: bool = False):
    highlighter = JSONHighlighter()

    get_server = requests.get('https://api.gofile.io/servers')
    servers = get_server.json()
    best_server = servers['data']['servers'][0]['name']

    files = []
    for _path in path:
        if not Path(_path).exists():
            rprint(
                f'[red]ERROR: [dim blue]"{Path(_path).absolute()}"[/dim blue] does not exist![/red]')
            continue
        if Path(_path).is_dir():
            dir_items = glob(str(Path(f'{_path}/**/*')), recursive=True)
            local_files = [x for x in dir_items if not Path(x).is_dir()]
            files.append(local_files)
        else:
            files.append([_path])
    files = sum(files, [])

    export_data = []
    urls = []
    folder_id = None

    # Create a live progress bar to display upload percentage, speed, and time remaining
    progress = Progress(
        "[progress.description]{task.description}",
        BarColumn(),
        "[progress.percentage]{task.percentage:>3.0f}%",
        "•",
        TransferSpeedColumn(),
        "•",
        TimeRemainingColumn()
    )

    with progress:
        for file in files:
            file_path = Path(file)
            file_size = file_path.stat().st_size
            task_id = progress.add_task(f"Uploading {file_path.name}", total=file_size)
            upload_resp = upload(file, best_server, folder_id, progress_bar=progress, task_id=task_id)
            upload_resp = upload_resp.json()

            if to_single_folder and not os.getenv('GOFILE_TOKEN'):
                rprint('[red]ERROR: Gofile token is required when passing `--to-single-folder`![/red]\n'
                       '[dim red]You can find your account token on this page: '
                       '[u][blue]https://gofile.io/myProfile[/blue][/u]\n'
                       'Copy it and export it as `GOFILE_TOKEN`. For example:\n'
                       'export GOFILE_TOKEN=\'xxxxxxxxxxxxxxxxx\'[/dim red]')
                sys.exit(1)
            elif to_single_folder and os.getenv('GOFILE_TOKEN'):
                folder_id = upload_resp['data']['parentFolder']

            ts = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
            file_abs = str(file_path.absolute())
            record = {'file': file_abs, 'timestamp': ts, 'response': upload_resp}

            url = upload_resp['data']['downloadPage']
            urls.append(url)

            if verbose:
                highlighted_resp = highlighter(json.dumps(record, indent=2))
                rprint(Panel(highlighted_resp))
            elif not to_single_folder:
                rprint(Panel.fit(
                    f'[yellow]File:[/yellow] [blue]{file}[/blue]\n'
                    f'[yellow]Download page:[/yellow] [u][blue]{url}[/blue][/u]'
                ))
            if export:
                export_data.append(record)

    if not urls:
        sys.exit()

    if to_single_folder:
        files_str = '\n'.join([str(Path(x).absolute()) for x in files])
        rprint(Panel.fit(
            f'[yellow]Files:[/yellow]\n[blue]{files_str}[/blue]\n'
            '[yellow]Download page:[/yellow] [u][blue]{urls[0]}[/blue][/u]'
        ))

    if export:
        export_fname = f'gofile_export_{int(time.time())}.json'
        with open(export_fname, 'w') as j:
            json.dump(export_data, j, indent=4)
        rprint(f'[green]Exported data to:[/green] [magenta]{export_fname}[/magenta]')

    if 'macOS' in platform() and open_urls:
        for url in urls:
            subprocess.call(['open', url])
            if to_single_folder:
                break


def opts():
    parser = argparse.ArgumentParser(
        description='Example: gofile <file/folder_path>')
    parser.add_argument(
        '-s',
        '--to-single-folder',
        help='Upload multiple files to the same folder. All files will share the same URL. '
             'This option requires a valid token exported as: `GOFILE_TOKEN`',
        action='store_true'
    )
    parser.add_argument(
        '-o',
        '--open-urls',
        help='Open the URL(s) in the browser when the upload is complete (macOS-only)',
        action='store_true'
    )
    parser.add_argument(
        '-e',
        '--export',
        help='Export upload response(s) to a JSON file',
        action='store_true'
    )
    parser.add_argument(
        '-vv',
        '--verbose',
        help='Show more information',
        action='store_true'
    )
    parser.add_argument(
        'path',
        nargs='+',
        help='Path to the file(s) and/or folder(s)'
    )
    return parser.parse_args()


def main():
    args = opts()
    gofile_upload(
        path=args.path,
        to_single_folder=args.to_single_folder,
        verbose=args.verbose,
        export=args.export,
        open_urls=args.open_urls,
    )


if __name__ == '__main__':
    main()
